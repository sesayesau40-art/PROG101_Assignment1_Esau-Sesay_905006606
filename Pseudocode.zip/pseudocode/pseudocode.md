# FloodWatch SL – Pseudocode

```
PROGRAM FloodWatchSL

// ---------- CONSTANTS ----------
CONSTANT RAIN_WATCH     = 50      // mm of rain in 3 hours
CONSTANT RAIN_WARNING   = 80
CONSTANT RAIN_SEVERE    = 120
CONSTANT LEVEL_WATCH    = 50      // % of drain / channel capacity
CONSTANT LEVEL_WARNING  = 75
CONSTANT LEVEL_SEVERE   = 90
CONSTANT MAX_ATTEMPTS   = 3

// ---------- MAIN MODULE ----------
BEGIN
    SET alertCount  = 0
    SET manualCount = 0
    SET redCount = 0, orangeCount = 0, yellowCount = 0, greenCount = 0

    OUTPUT "Enter number of monitoring stations:"
    INPUT stationCount

    SET i = 1
    WHILE i <= stationCount DO
        OUTPUT "Enter station / community name:"
        INPUT stationName

        IF GetValidatedReadings(stationName, rain, level, saturated, floodProne) = TRUE THEN
            SET risk = CalculateRiskLevel(rain, level, saturated)
            SET risk = ApplyEscalation(risk, floodProne)

            IF risk <> "GREEN" THEN
                SET message = BuildAlertMessage(stationName, risk, rain, level)
                CALL SendAlert(message)
                SET alertCount = alertCount + 1
            END IF

            CALL LogRecord(stationName, rain, level, risk)
            CALL UpdateCounters(risk)
        ELSE
            SET manualCount = manualCount + 1
            OUTPUT stationName + ": invalid data - MANUAL CHECK NEEDED"
        END IF

        SET i = i + 1
    END WHILE

    CALL DisplaySummary(stationCount, alertCount, manualCount)
END

// ---------- FUNCTION: INPUT + VALIDATION (repetition) ----------
FUNCTION GetValidatedReadings(stationName, BYREF rain, BYREF level,
                              BYREF saturated, BYREF floodProne) RETURNS Boolean
    SET attempts = 0
    SET valid = FALSE

    WHILE valid = FALSE AND attempts < MAX_ATTEMPTS DO
        OUTPUT "Rainfall in last 3 hours (mm):"        INPUT rain
        OUTPUT "Water level (% of channel capacity):"  INPUT level
        OUTPUT "Ground saturated? (TRUE/FALSE):"       INPUT saturated
        OUTPUT "Flood-prone community? (TRUE/FALSE):"  INPUT floodProne

        IF IsValid(rain, level, saturated) THEN
            SET valid = TRUE
        ELSE
            OUTPUT "Invalid reading - please re-enter"
            SET attempts = attempts + 1
        END IF
    END WHILE

    RETURN valid
END FUNCTION

FUNCTION IsValid(rain, level, saturated) RETURNS Boolean
    RETURN (rain >= 0) AND (level >= 0) AND (level <= 100)
END FUNCTION

// ---------- FUNCTION: RISK CLASSIFICATION (decision structure) ----------
FUNCTION CalculateRiskLevel(rain, level, saturated) RETURNS String
    IF rain >= RAIN_SEVERE OR level >= LEVEL_SEVERE THEN
        RETURN "RED"
    ELSE IF (rain >= RAIN_WARNING AND level >= LEVEL_WATCH) OR level >= LEVEL_WARNING THEN
        RETURN "ORANGE"
    ELSE IF rain >= RAIN_WATCH OR (level >= LEVEL_WATCH AND saturated = TRUE) THEN
        RETURN "YELLOW"
    ELSE
        RETURN "GREEN"
    END IF
END FUNCTION

FUNCTION ApplyEscalation(risk, floodProne) RETURNS String
    IF floodProne = TRUE AND risk = "YELLOW" THEN
        RETURN "ORANGE"
    END IF
    RETURN risk
END FUNCTION

// ---------- FUNCTION: ALERT MESSAGE ----------
FUNCTION BuildAlertMessage(stationName, risk, rain, level) RETURNS String
    IF risk = "RED" THEN
        SET advice = "SEVERE FLOOD RISK. Move to higher ground NOW."
    ELSE IF risk = "ORANGE" THEN
        SET advice = "Flooding likely. Prepare to leave; move children and elderly first."
    ELSE
        SET advice = "Flooding possible. Stay alert and clear drains."
    END IF
    RETURN risk + " ALERT - " + stationName + ": " + advice +
           " (Rain " + rain + "mm, Water " + level + "%)"
END FUNCTION

FUNCTION SendAlert(message)
    OUTPUT "SMS/Alert sent: " + message
END FUNCTION

// ---------- FUNCTION: RECORD KEEPING & SUMMARY ----------
FUNCTION LogRecord(stationName, rain, level, risk)
    APPEND (date, stationName, rain, level, risk) TO floodLog
END FUNCTION

FUNCTION UpdateCounters(risk)
    IF risk = "RED" THEN redCount = redCount + 1
    ELSE IF risk = "ORANGE" THEN orangeCount = orangeCount + 1
    ELSE IF risk = "YELLOW" THEN yellowCount = yellowCount + 1
    ELSE greenCount = greenCount + 1
    END IF
END FUNCTION

FUNCTION DisplaySummary(stationCount, alertCount, manualCount)
    OUTPUT "Stations processed: " + stationCount
    OUTPUT "Alerts sent: " + alertCount
    OUTPUT "RED: " + redCount + "  ORANGE: " + orangeCount +
           "  YELLOW: " + yellowCount + "  GREEN: " + greenCount
    OUTPUT "Manual checks needed: " + manualCount
END FUNCTION
```
