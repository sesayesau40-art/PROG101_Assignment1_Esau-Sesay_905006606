# FloodWatch SL - Step-by-Step Algorithm

1. START.
2. Define constants: RAIN_WATCH = 50, RAIN_WARNING = 80, RAIN_SEVERE = 120 (mm in 3 hours); LEVEL_WATCH = 50, LEVEL_WARNING = 75, LEVEL_SEVERE = 90 (% of channel capacity); MAX_ATTEMPTS = 3.
3. Set alertCount = 0, manualCount = 0, and redCount = orangeCount = yellowCount = greenCount = 0.
4. Input stationCount (number of monitoring stations to process).
5. Set i = 1.
6. WHILE i <= stationCount, repeat Steps 7 to 17.
7. Input stationName.
8. Set attempts = 0 and valid = FALSE.
9. WHILE valid = FALSE AND attempts < MAX_ATTEMPTS: input rain, level, saturated and floodProne.
10. IF rain >= 0 AND level >= 0 AND level <= 100 THEN set valid = TRUE; ELSE display 'Invalid reading - please re-enter' and set attempts = attempts + 1.
11. IF valid = FALSE after the loop: set manualCount = manualCount + 1, display 'MANUAL CHECK NEEDED', and go to Step 17.
12. Classify risk: IF rain >= RAIN_SEVERE OR level >= LEVEL_SEVERE THEN RED; ELSE IF (rain >= RAIN_WARNING AND level >= LEVEL_WATCH) OR level >= LEVEL_WARNING THEN ORANGE; ELSE IF rain >= RAIN_WATCH OR (level >= LEVEL_WATCH AND saturated = TRUE) THEN YELLOW; ELSE GREEN.
13. Escalate: IF floodProne = TRUE AND risk = YELLOW THEN set risk = ORANGE.
14. IF risk is not GREEN: build the alert message for the risk level, send the alert, and set alertCount = alertCount + 1.
15. Log the record (date, stationName, rain, level, risk).
16. Increase the counter for the risk level (redCount, orangeCount, yellowCount or greenCount).
17. Set i = i + 1 and return to Step 6.
18. Display the summary: stations processed, alerts sent, count per risk level, manual checks needed.
19. END.

